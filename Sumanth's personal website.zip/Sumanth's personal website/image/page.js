function ValidateEmail(inputText)
{
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
if(inputText.value.match(mailformat))
{
alert("This Field is required");
document.form1.text1.focus();
return true;
}
else
{
alert("Please use valid email address");
document.form1.text1.focus();
return false;
}
}